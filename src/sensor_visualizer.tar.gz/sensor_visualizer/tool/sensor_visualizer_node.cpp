//
// Created by zxkj on 18-12-12.
//

#include "sensor_visualizer.h"


int main(int argc, char **argv)
{
    ros::init(argc, argv, "sensor_visualizer");

    SensorVisualizer *sensorvisualizer = new SensorVisualizer;

    sensorvisualizer->init();
    sensorvisualizer->doListening();


    delete(sensorvisualizer);

    return 0;
}

