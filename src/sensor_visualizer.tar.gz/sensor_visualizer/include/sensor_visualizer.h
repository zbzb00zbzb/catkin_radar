//
// Created by zxkj on 18-12-12.
//

#ifndef SENSOR_VISUALIZER_SENSOR_VISUALIZER_H
#define SENSOR_VISUALIZER_SENSOR_VISUALIZER_H

#include "ros/ros.h"
#include "conti_radar_msgs/Objects.h"
#include "conti_radar_msgs/Object.h"
#include "visualization_msgs/Marker.h"

class SensorVisualizer
{
private:
    ros::NodeHandle node_handle_;
    ros::Subscriber recv_objects_sub_;

    ros::Publisher send_visualizer_pub_;

public:
    SensorVisualizer();
    ~SensorVisualizer();


    void init();
    void doListening();

    void objectsCallback(const conti_radar_msgs::Objects::ConstPtr &objects);
};



#endif //SENSOR_VISUALIZER_SENSOR_VISUALIZER_H
